export const ROOT_URL = 'http://ec2-13-55-225-21.ap-southeast-2.compute.amazonaws.com:3090';
export const FILE_UPLOAD_URL = 'https://test-appapi.clientskey.com:3333/image_upload';
