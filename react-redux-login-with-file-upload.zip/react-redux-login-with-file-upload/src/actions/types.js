export const AUTH_USER = 'auth_user';
export const UPLOAD_SUCCESS = 'upload_success';
export const UPLOAD_ERROR = 'upload_error';
export const IMAGE_LIST_DATA = 'image_list_data';
